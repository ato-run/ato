#!/bin/sh
# Minimal native macOS route for the cross-Derivation state fixture.
#
# It serves the capsule's proof document on the loopback port the Derivation
# declares and records progress in the Run-scoped state slot this Run receives
# as $ATO_STATE_PATH_SAVE (the declared slot is delivered by path). The runtime
# applies Seatbelt, which allows reads of /usr, /System, /Library, the artifact
# and the workspace only, so the system interpreter is named by absolute path
# rather than resolved through PATH.
directory=$(dirname "$0")
state="${ATO_STATE_PATH_SAVE:-}"
if [ -n "$state" ]; then
  if [ -f "$state/save.json" ]; then
    cp "$state/save.json" "$state/save.previous.json" 2>/dev/null || true
  fi
  printf '{"progress":"native-run","source":"native-macos"}\n' > "$state/save.json"
fi
exec /usr/bin/python3 -m http.server 18080 --bind 127.0.0.1 --directory "$directory"
