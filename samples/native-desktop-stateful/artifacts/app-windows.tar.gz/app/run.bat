@echo off
REM Minimal native Windows route for the portable fixture. It serves the
REM capsule's proof document on the loopback port the Derivation declares.
python -m http.server 18080 --bind 127.0.0.1 --directory "%~dp0"
