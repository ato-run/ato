#!/bin/sh
# Minimal native macOS route for the multi-Derivation fixture.
#
# It serves the capsule's proof document on the loopback port the Derivation
# declares (18080). The runtime launches it through Seatbelt, which allows reads
# of /usr, /System, /Library, the artifact and the workspace only — so this
# wrapper runs the system interpreter by absolute path rather than resolving
# `python3` through PATH, which may point at a home-directory shim the sandbox
# does not allow. The wrapper is unsigned, so the fixture's signature policy is
# require-valid-or-local-override.
exec /usr/bin/python3 -m http.server 18080 --bind 127.0.0.1 --directory "$(dirname "$0")"
