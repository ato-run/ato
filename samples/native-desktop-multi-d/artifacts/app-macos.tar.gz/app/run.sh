#!/bin/sh
# Minimal native macOS route for the portable fixture. It serves the capsule's
# proof document on the loopback port the Derivation declares (18080). PR5's
# adapter launches it through Seatbelt and reads /proof.txt with the common
# verifier; this wrapper is unsigned, so the fixture's signature policy is
# require-valid-or-local-override.
exec python3 -m http.server 18080 --bind 127.0.0.1 --directory "$(dirname "$0")"
